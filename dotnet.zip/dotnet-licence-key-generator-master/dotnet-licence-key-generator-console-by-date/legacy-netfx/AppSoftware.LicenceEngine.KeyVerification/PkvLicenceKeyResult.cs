﻿namespace AppSoftware.LicenceEngine.KeyVerification
{
    public enum PkvLicenceKeyResult
    {
        KeyGood = 0,
        KeyInvalid = 1,
        KeyBlackListed = 2,
        KeyPhoney = 3
    }
}
