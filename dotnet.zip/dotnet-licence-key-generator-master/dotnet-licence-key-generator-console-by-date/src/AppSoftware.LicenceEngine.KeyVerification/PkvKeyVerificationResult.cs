﻿namespace AppSoftware.LicenceEngine.KeyVerification
{
    public enum PkvKeyVerificationResult
    {
        KeyIsValid = 0,
        KeyIsInvalid = 1,
        KeyBlackListed = 2,
        KeyPhoney = 3
    }
}
