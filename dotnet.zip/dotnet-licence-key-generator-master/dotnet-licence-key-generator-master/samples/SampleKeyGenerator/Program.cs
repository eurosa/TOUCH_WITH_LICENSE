﻿using System;
using AppSoftware.LicenceEngine.Common;
using AppSoftware.LicenceEngine.KeyGenerator;
using System.Management;
using System.Diagnostics;
using System.Net.NetworkInformation;
using System.Linq;
using System.Text;
using System.Collections;

namespace SampleKeyGenerator
{
    class Program
    {
        private static ulong macAsNumber;

        static void Main(string[] args)
        {

            var arlist = new ArrayList(); // recommended 

            int nProcessID = Process.GetCurrentProcess().Id;

            var macAddr = (from nic in NetworkInterface.GetAllNetworkInterfaces()
                           where nic.OperationalStatus == OperationalStatus.Up
                           select nic.GetPhysicalAddress().ToString()).FirstOrDefault();

            byte[] bytes = Encoding.ASCII.GetBytes(macAddr);

            byte[] bytesData = new byte[100];

            Console.WriteLine("cpu Id: " + ByteArrayToString(bytes) + " Machine:" + macAddr); 
            Console.WriteLine("cpu Id: " + nProcessID + " Machine:" + macAddr);


            macAsNumber = Convert.ToUInt64(macAddr, 16);

            string str = macAddr;
            KeyByteSet[] keyByteSets1 = new KeyByteSet[str.Length];
            // Creating byte array of string length 
            byte[] byt = new byte[str.Length];

            // converting each character into byte 
            // and store it
            for (int i = 0; i < str.Length; i++)
            {
                byt[i] = Convert.ToByte(str[i]);
            }

        

        

            while (true)
            {
                // Here in SampleKeyGenerator is the full set of KeyByteSet used to generate the licence key.
                // You should change these values in your solution.

                int i = 1;
                int j = 6;
                int length = 0;
                if ((bytes.Length + 1) < 12)
                {
                    length = 12;
                }
                else {
                    length = (bytes.Length + 1);
                }
      
                foreach (byte b in bytes)
                {
                    bytesData[i] = b;

                    Console.WriteLine("Byte Data: "+b.ToString().Trim());

                    //  keyByteSets1[i] = new KeyByteSet(keyByteNumber: i, keyByteA: b, keyByteB: b, keyByteC: (byte)(j++));
                    //  new KeyByteSet(keyByteNumber: 1, keyByteA: 58, keyByteB: 6, keyByteC: 97);
                    //  Console.WriteLine(i);
                    i++;
                    j++;

                }

                // printing characters with byte values
                for (int ii = 0; ii < byt.Length; ii++)
                {
                    Console.WriteLine("Byte of char \'" + str[ii] + "\' : " + byt[ii]);
                    if (ii > 0)
                    {

                         keyByteSets1[ii] = new KeyByteSet(keyByteNumber: ii, keyByteA: byt[ii], keyByteB: (byte)ii, keyByteC: (byte)ii);
                         
                    }
                }

                var keyByteSets = new[]
                  {

                      // keyByteSets1[1],
                      // keyByteSets1[2]

                      new KeyByteSet(keyByteNumber: 1, keyByteA: byt[0], keyByteB: byt[0], keyByteC: byt[0]),
                      new KeyByteSet(keyByteNumber: 2, keyByteA: byt[1], keyByteB: byt[1], keyByteC: byt[1]),
                      new KeyByteSet(keyByteNumber: 3, keyByteA: byt[2], keyByteB: byt[2], keyByteC: byt[2]),
                      new KeyByteSet(keyByteNumber: 4, keyByteA: byt[3], keyByteB: byt[3], keyByteC: byt[3]),
                      new KeyByteSet(keyByteNumber: 5, keyByteA: byt[4], keyByteB: byt[4], keyByteC: byt[4]),
                      new KeyByteSet(keyByteNumber: 6, keyByteA: byt[5], keyByteB: byt[5], keyByteC: byt[5]),
                      new KeyByteSet(keyByteNumber: 7, keyByteA: byt[6], keyByteB: byt[6], keyByteC: byt[6]),
                      new KeyByteSet(keyByteNumber: 8, keyByteA: byt[7], keyByteB: byt[7], keyByteC: byt[7])
                    
                   /* new KeyByteSet(keyByteNumber: 1, keyByteA: bytesData[1], keyByteB: 6, keyByteC: 97),
                      new KeyByteSet(keyByteNumber: 2, keyByteA: bytesData[2], keyByteB: 254, keyByteC: 23),
                      new KeyByteSet(keyByteNumber: 3, keyByteA: bytesData[3], keyByteB: 185, keyByteC: 69),
                      new KeyByteSet(keyByteNumber: 4, keyByteA: bytesData[4], keyByteB: 93, keyByteC: 41),
                      new KeyByteSet(keyByteNumber: 5, keyByteA: bytesData[5], keyByteB: 4, keyByteC: 234),
                      new KeyByteSet(keyByteNumber: 6, keyByteA: bytesData[6], keyByteB: 56, keyByteC: 49),
                      new KeyByteSet(keyByteNumber: 7, keyByteA: bytesData[7], keyByteB: 45, keyByteC: 142),
                      new KeyByteSet(keyByteNumber: 8, keyByteA: bytesData[8], keyByteB: 89, keyByteC: 34),
                      new KeyByteSet(keyByteNumber: 9, keyByteA: bytesData[9], keyByteB: 90, keyByteC: 67),
                      new KeyByteSet(keyByteNumber: 10, keyByteA: bytesData[10], keyByteB: 91, keyByteC: 81),
                      new KeyByteSet(keyByteNumber: 11, keyByteA: bytesData[11], keyByteB: 92, keyByteC: 56),
                      new KeyByteSet(keyByteNumber: 12, keyByteA: bytesData[12], keyByteB: 96, keyByteC: 78)

                     /* new KeyByteSet(keyByteNumber: 13, keyByteA: bytesData[13], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 14, keyByteA: bytesData[14], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 15, keyByteA: bytesData[15], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 16, keyByteA: bytesData[16], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 17, keyByteA: bytesData[17], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 18, keyByteA: bytesData[18], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 19, keyByteA: bytesData[19], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 20, keyByteA: bytesData[20], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 21, keyByteA: bytesData[21], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 22, keyByteA: bytesData[22], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 23, keyByteA: bytesData[23], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 24, keyByteA: bytesData[24], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 25, keyByteA: bytesData[25], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 26, keyByteA: bytesData[26], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 27, keyByteA: bytesData[27], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 28, keyByteA: bytesData[28], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 29, keyByteA: bytesData[29], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 30, keyByteA: bytesData[30], keyByteB: 88, keyByteC: 32),
                      new KeyByteSet(keyByteNumber: 31, keyByteA: bytesData[31], keyByteB: 88, keyByteC: 32),*/
                  };

              
              /*  keyByteSets1[0] =  new KeyByteSet(keyByteNumber: 1, keyByteA: 58, keyByteB: 6, keyByteC: 97);
                keyByteSets1[1] = new KeyByteSet(keyByteNumber: 2, keyByteA: 96, keyByteB: 254, keyByteC: 23);
                keyByteSets1[2] = new KeyByteSet(keyByteNumber: 3, keyByteA: 11, keyByteB: 185, keyByteC: 69);
                keyByteSets1[3] = new KeyByteSet(keyByteNumber: 4, keyByteA: 2, keyByteB: 93, keyByteC: 41);
                keyByteSets1[4] = new KeyByteSet(keyByteNumber: 5, keyByteA: 62, keyByteB: 4, keyByteC: 234);
                keyByteSets1[5] = new KeyByteSet(keyByteNumber: 6, keyByteA: 200, keyByteB: 56, keyByteC: 49);
                keyByteSets1[6] = new KeyByteSet(keyByteNumber: 7, keyByteA: 89, keyByteB: 45, keyByteC: 142);
                keyByteSets1[7] = new KeyByteSet(keyByteNumber: 8, keyByteA: 6, keyByteB: 88, keyByteC: 32);*/
                // A unique key will be created for the seed value. This value could be a user ID or something
                // else depending on your application logic.

                int seed = new Random().Next(0, int.MaxValue);

                Console.WriteLine("Seed (for example user ID) is:");
                Console.WriteLine(seed);

                /* var mbs = new ManagementObjectSearcher("Select ProcessorId From Win32_processor");
                ManagementObjectCollection mbsList = mbs.Get();
                string id = "";
                foreach (ManagementObject mo in mbsList)
                {
                    // NuGet\Install-Package System.Management -Version 7.0.0
                    id = mo["ProcessorId"].ToString();
                    Console.WriteLine("cpu id: " + id);
                    break;
                } */

                // Generate the key ... 
             
                var pkvLicenceKeyGenerator = new PkvKeyGenerator();
                
                string licenceKey = pkvLicenceKeyGenerator.MakeKey(seed, keyByteSets);
                
                Console.WriteLine("Generated licence key is:");
                
                Console.WriteLine(licenceKey);

                // The values output can now be copied into the SampleKeyVerification console app to demonstrate
                // verification.

                Console.WriteLine("\nCopy these values to a running instance of SampleKeyVerification to test key verification.");

                Console.WriteLine("\nPress any key to generate another licence key.");

                Console.ReadKey();
            }
        }
        public static string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }
    }
}
