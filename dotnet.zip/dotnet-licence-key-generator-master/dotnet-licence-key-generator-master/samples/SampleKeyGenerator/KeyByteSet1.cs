﻿using System;

namespace SampleKeyGenerator
{


    public class KeyByteSet1
    {
        public int KeyByteNumber { get; set; }

        public byte KeyByteA { get; set; }

        public byte KeyByteB { get; set; }

        public byte KeyByteC { get; set; }

        public KeyByteSet1(int keyByteNumber, byte keyByteA, byte keyByteB, byte keyByteC)
        {
            if (keyByteNumber < 1)
            {
                throw new ArgumentException("keyByteNumber should be greater or equal to 1", "keyByteNumber");
            }

            KeyByteNumber = keyByteNumber;
            KeyByteA = keyByteA;
            KeyByteB = keyByteB;
            KeyByteC = keyByteC;
        }
        public KeyByteSet1() { 
        
        }
    }
}
